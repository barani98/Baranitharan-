from io import BytesIO
import html
from docx import Document
from docx.shared import Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH
from fpdf import FPDF

def sanitize_text(text):
    replacements = {
        "\u2018": "'", "\u2019": "'", "\u201c": '"',
        "\u201d": '"', "\u2013": "-", "\u2014": "-", "\u00a0": " "
    }
    for old, new in replacements.items():
        text = text.replace(old, new)
    return text.strip()

def format_html_preview(text):
    safe = html.escape(sanitize_text(text))
    safe = safe.replace("\n\n", "</p><p>").replace("\n", "<br>")
    return f'<div class="legal-preview"><p>{safe}</p></div>'

def format_docx(text, doc_type):
    doc = Document()
    style = doc.styles["Normal"]
    style.font.name = "Times New Roman"
    style.font.size = Pt(12)

    title = doc.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = title.add_run(doc_type.upper())
    run.bold = True
    run.font.size = Pt(16)

    for block in sanitize_text(text).split("\n\n"):
        if block.strip():
            doc.add_paragraph(block.strip())

    footer = doc.sections[0].footer.paragraphs[0]
    footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
    footer.add_run("LegalEase - AI-generated draft. Review before legal use.")

    output = BytesIO()
    doc.save(output)
    return output.getvalue()

class LegalPDF(FPDF):
    def footer(self):
        self.set_y(-15)
        self.set_font("Helvetica", size=8)
        self.cell(0, 10,
                  "LegalEase - AI-generated draft. Review before legal use.",
                  align="C")

def format_pdf(text, doc_type):
    pdf = LegalPDF()
    pdf.set_auto_page_break(auto=True, margin=18)
    pdf.add_page()
    pdf.set_font("Helvetica", "B", 16)
    pdf.cell(0, 10, doc_type.upper(), new_x="LMARGIN", new_y="NEXT", align="C")
    pdf.ln(5)
    pdf.set_font("Helvetica", size=11)
    for block in sanitize_text(text).split("\n\n"):
        if block.strip():
            pdf.multi_cell(0, 7, block.strip())
            pdf.ln(3)
    return bytes(pdf.output())

def format_txt(text):
    return sanitize_text(text).encode("utf-8")
