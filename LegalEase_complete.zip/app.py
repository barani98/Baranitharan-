import requests
import streamlit as st
from document_utils import format_docx, format_pdf, format_txt, format_html_preview

st.set_page_config(page_title="LegalEase", page_icon="⚖️", layout="wide")
st.title("⚖️ LegalEase")
st.caption("AI-Powered Legal Document Generator")
st.warning("AI-generated drafts are for informational purposes and should be professionally reviewed.")

BACKEND_URL = st.sidebar.text_input("FastAPI URL", "http://127.0.0.1:8000").rstrip("/")

document_type = st.selectbox("Document Type", [
    "Agreement", "Contract", "NDA (Non-Disclosure Agreement)",
    "Lease Agreement", "Employment Offer Letter",
    "Freelance Work Contract", "Other"
])
if document_type == "Other":
    document_type = st.text_input("Enter document type")

parties = st.text_area("Parties Involved",
                       placeholder="Jane Doe (Service Provider), TechNova Inc. (Client)")
terms = st.text_area("Terms & Conditions",
                      placeholder="Payment within 30 days; Confidentiality must be maintained")
dates = st.text_input("Effective Date", placeholder="September 28, 2026")

if "document" not in st.session_state:
    st.session_state.document = ""

if st.button("Generate Document", type="primary"):
    if not all([document_type, parties, terms, dates]):
        st.error("Please complete all fields.")
    else:
        try:
            with st.spinner("Generating document..."):
                response = requests.post(
                    f"{BACKEND_URL}/generate",
                    json={"document_type": document_type, "parties": parties,
                          "terms": terms, "dates": dates},
                    timeout=120
                )
                response.raise_for_status()
                st.session_state.document = response.json()["document"]
            st.success("Document generated.")
        except requests.RequestException as exc:
            st.error(f"Could not connect to FastAPI: {exc}")
        except Exception as exc:
            st.error(f"Generation failed: {exc}")

if st.session_state.document:
    st.subheader("Document Preview")
    st.markdown(format_html_preview(st.session_state.document), unsafe_allow_html=True)

    st.subheader("Edit Document")
    st.session_state.document = st.text_area(
        "Edit the generated document",
        value=st.session_state.document,
        height=500
    )

    col1, col2, col3 = st.columns(3)
    with col1:
        st.download_button("Download TXT", format_txt(st.session_state.document),
                           "legalease_document.txt", "text/plain")
    with col2:
        st.download_button("Download DOCX", format_docx(st.session_state.document, document_type),
                           "legalease_document.docx",
                           "application/vnd.openxmlformats-officedocument.wordprocessingml.document")
    with col3:
        st.download_button("Download PDF", format_pdf(st.session_state.document, document_type),
                           "legalease_document.pdf", "application/pdf")
