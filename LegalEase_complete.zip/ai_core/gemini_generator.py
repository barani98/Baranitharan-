import os
from dotenv import load_dotenv
import google.generativeai as genai

load_dotenv()

class GeminiDocumentGenerator:
    def __init__(self):
        api_key = os.getenv("GEMINI_API_KEY")
        if not api_key:
            raise RuntimeError("GEMINI_API_KEY is missing. Add it to .env.")
        genai.configure(api_key=api_key)
        self.model = genai.GenerativeModel("gemini-1.5-pro")

    def generate_document(self, document_type, parties, terms, dates):
        prompt = f"""
You are LegalEase, an AI assistant for drafting legal documents.

Create a structured draft for:
Document type: {document_type}
Parties: {parties}
Terms and conditions: {terms}
Effective date: {dates}

Requirements:
- Use a clear professional legal-document structure.
- Include title, parties, effective date, clauses and signature section.
- Convert supplied terms into appropriate clauses.
- Do not invent personal details.
- State that this is an AI-generated draft requiring professional review.
- Return plain text only.
"""
        response = self.model.generate_content(prompt)
        return response.text.strip()
